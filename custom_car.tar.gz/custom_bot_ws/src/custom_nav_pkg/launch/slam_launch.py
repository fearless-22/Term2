import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    pkg_name = 'custom_nav_pkg'
    pkg_dir = get_package_share_directory(pkg_name)

    # 文件路径
    urdf_path = os.path.join(pkg_dir, 'urdf', 'custom_bot.urdf')
    world_path = os.path.join(pkg_dir, 'worlds', 'track.world')
    cartographer_config_dir = os.path.join(pkg_dir, 'config')
    cartographer_config_basename = 'cartographer_2d.lua'

    # 读取URDF内容
    with open(urdf_path, 'r') as infp:
        robot_desc = infp.read()

    # 1. 启动 Gazebo
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(get_package_share_directory('gazebo_ros'), 'launch', 'gazebo.launch.py')
        ),
        launch_arguments={'world': world_path}.items()
    )

    # 2. 在 Gazebo 中生成小车
    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-entity', 'custom_bot', '-file', urdf_path, '-x', '0.0', '-y', '1.5', '-z', '0.2'],
        output='screen'
    )

    # 3. 启动 robot_state_publisher (发布URDF中的静态TF树)
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_desc, 'use_sim_time': True}]
    )

    # 4. 启动 Cartographer 节点
    cartographer_node = Node(
        package='cartographer_ros',
        executable='cartographer_node',
        name='cartographer_node',
        output='screen',
        parameters=[{'use_sim_time': True}],
        arguments=[
            '-configuration_directory', cartographer_config_dir,
            '-configuration_basename', cartographer_config_basename
        ]
    )

    # 5. 启动 Cartographer 栅格地图转换节点
    cartographer_occupancy_grid_node = Node(
        package='cartographer_ros',
        executable='cartographer_occupancy_grid_node',
        name='cartographer_occupancy_grid_node',
        output='screen',
        parameters=[{'use_sim_time': True, 'resolution': 0.02}]
    )

    # 6. 启动 RViz2
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        parameters=[{'use_sim_time': True}]
    )

    return LaunchDescription([
        gazebo,
        spawn_entity,
        robot_state_publisher,
        cartographer_node,
        cartographer_occupancy_grid_node,
        rviz_node
    ])
